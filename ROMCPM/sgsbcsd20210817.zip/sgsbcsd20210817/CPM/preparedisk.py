#!/usr/bin/python3
# by Daniel L. Marks, zlib license
# This program assembles a CP/M SD card image from pieces
# given by a list of file offsets and filenames in a list file
# Usage:
# preparedisk.py <outputfilename> <input text file name with list>

import sys

outputfile=sys.argv[1]
inputfilelist=sys.argv[2:]

flw = open(outputfile,"wb")
print("Opening file for writing:",outputfile)

for inputfile in inputfilelist:
	print("File list:",inputfilelist)
	flr = open(inputfile,"r")
	lines = flr.readlines()
	flr.close()
	for line in lines:
		line = line.rstrip()
		if len(line)>0:
			bytelen,separator,filename = line.partition(',')
			bytelen = int(bytelen,base=16)
			print('Copy file',filename,'to position:',hex(bytelen))
			flr = open(filename,"rb")
			contents = flr.read()
			flr.close()
			while flw.tell() < bytelen:
				flw.write(contents)
flw.close()

#!/usr/bin/python3
# by Daniel L. Marks, zlib license
# This program creates a ROM image from Intel HEX record files
#
# combinerom.py <hex length of rom> <base address of rom> <outputfilename> <first intel hex record file> <second intel hex record file...>

import sys

try:
	imglen = int(sys.argv[1],base=16)
	rombase = int(sys.argv[2],base=16)
except ValueError:
	print("Invalid values for the len or rombase")
	sys.exit(1)

outputfile=sys.argv[3]

romimg=bytearray(b' ' * imglen)
occupied=bytearray(b'\x00' * imglen)

print('Rom image length:',hex(imglen))
print('Rom image at:',hex(rombase))
print('Writing image to:',outputfile)

for filenumber in range(4,len(sys.argv)):
	filename=sys.argv[filenumber]
	print('Reading file:',filename)
	print('Overlaps: ',end='')
	with open(filename,"r") as fl:
		lines = fl.readlines()
		for line in lines:
			line = line.rstrip()
			if line[0] == ':':
				lenline = int(line[1:3],base=16)
				addr = int(line[3:7],base=16)
				rectype = int(line[7:9],base=16)
				addrback = addr - rombase
				if rectype == 0:
					for ind in range(9,9+lenline*2,2):
						dat = int(line[ind:ind+2],base=16)
						if (addrback < 0) or (addrback >= imglen):
							print("Error! Exceeded image length:",hex(addrback))
							sys.exit(1)
						else:
							romimg[addrback] = dat
							if occupied[addrback] != 0:
								print(hex(addrback+rombase),' ',end='')
							occupied[addrback] = 1
							addrback = addrback + 1
		print('')

fl = open(outputfile,"wb")
fl.write(romimg)
fl.close()
print("Written file:",outputfile)
